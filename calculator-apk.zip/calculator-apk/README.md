# آلة حاسبة (Android)

مشروع Android بسيط بدون أي مكتبات خارجية (Java فقط).

## طرق الحصول على ملف APK

### 1) Android Studio (الأسهل)
1. افتح مجلد المشروع في Android Studio واترك المزامنة (Sync) تنتهي.
2. من القائمة: Build ← Build Bundle(s) / APK(s) ← Build APK(s).
3. ستجد الملف في: `app/build/outputs/apk/debug/app-debug.apk`

### 2) سطر الأوامر (يتطلب JDK 17 وAndroid SDK)
```
./gradlew assembleDebug
```

### 3) بدون تثبيت أي شيء (GitHub Actions)
1. ارفع المجلد كاملاً إلى مستودع GitHub جديد.
2. افتح تبويب Actions ← Build APK ← شغّله.
3. حمّل الملف من Artifacts باسم `calculator-apk`.

## التثبيت على الهاتف
انقل `app-debug.apk` إلى الهاتف، وفعّل «التثبيت من مصادر غير معروفة»، ثم افتحه.
