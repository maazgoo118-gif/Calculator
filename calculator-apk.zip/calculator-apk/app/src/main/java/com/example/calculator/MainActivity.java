package com.example.calculator;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.math.BigDecimal;
import java.math.MathContext;

public class MainActivity extends Activity {

    private static final int BG = Color.parseColor("#121212");
    private static final int NUM = Color.parseColor("#2A2A2E");
    private static final int OP = Color.parseColor("#FF9F0A");
    private static final int FUNC = Color.parseColor("#4A4A50");

    private final StringBuilder expr = new StringBuilder();
    private TextView exprView;
    private TextView resultView;

    private static final String[][] KEYS = {
            {"C", "⌫", "%", "÷"},
            {"7", "8", "9", "×"},
            {"4", "5", "6", "−"},
            {"1", "2", "3", "+"},
            {"0", ".", "="}
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        root.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        root.setFitsSystemWindows(true);
        int pad = dp(12);
        root.setPadding(pad, pad, pad, pad);

        // منطقة العرض
        LinearLayout display = new LinearLayout(this);
        display.setOrientation(LinearLayout.VERTICAL);
        display.setGravity(Gravity.BOTTOM | Gravity.END);
        display.setPadding(dp(12), 0, dp(12), dp(12));

        exprView = new TextView(this);
        exprView.setTextColor(Color.parseColor("#9E9E9E"));
        exprView.setTextSize(28);
        exprView.setGravity(Gravity.END);
        exprView.setSingleLine(true);

        resultView = new TextView(this);
        resultView.setTextColor(Color.WHITE);
        resultView.setTextSize(52);
        resultView.setGravity(Gravity.END);
        resultView.setSingleLine(true);
        resultView.setText("0");

        display.addView(exprView, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        display.addView(resultView, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        root.addView(display, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 3f));

        // لوحة الأزرار
        LinearLayout pad2 = new LinearLayout(this);
        pad2.setOrientation(LinearLayout.VERTICAL);
        root.addView(pad2, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 5f));

        for (String[] row : KEYS) {
            LinearLayout r = new LinearLayout(this);
            r.setOrientation(LinearLayout.HORIZONTAL);
            for (String key : row) {
                float weight = key.equals("=") ? 2f : 1f;
                r.addView(makeButton(key), buttonParams(weight));
            }
            pad2.addView(r, new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
        }

        setContentView(root);
    }

    private Button makeButton(final String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextSize(26);
        b.setTextColor(Color.WHITE);
        int color = NUM;
        if ("÷×−+=".contains(label)) color = OP;
        else if (label.equals("C") || label.equals("⌫") || label.equals("%")) color = FUNC;
        GradientDrawable shape = new GradientDrawable();
        shape.setCornerRadius(dp(24));
        shape.setColor(color);
        b.setBackground(shape);
        b.setStateListAnimator(null);
        b.setOnClickListener(v -> onKey(label));
        return b;
    }

    private LinearLayout.LayoutParams buttonParams(float weight) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.MATCH_PARENT, weight);
        int m = dp(5);
        p.setMargins(m, m, m, m);
        return p;
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    // ---------- منطق الإدخال ----------

    private void onKey(String k) {
        switch (k) {
            case "C":
                expr.setLength(0);
                break;
            case "⌫":
                if (expr.length() > 0) expr.setLength(expr.length() - 1);
                break;
            case "=": {
                String r = evaluate(expr.toString());
                if (r != null && !r.equals("خطأ")) {
                    expr.setLength(0);
                    expr.append(r.replace("-", "−"));
                    exprView.setText("");
                    resultView.setText(r);
                    return;
                }
                resultView.setText("خطأ");
                return;
            }
            default:
                appendToken(k);
        }
        refresh();
    }

    private void appendToken(String k) {
        boolean isOp = "÷×−+".contains(k);
        int n = expr.length();
        char last = n > 0 ? expr.charAt(n - 1) : 0;
        boolean lastIsOp = n > 0 && "÷×−+".indexOf(last) >= 0;

        if (isOp) {
            if (n == 0) {
                if (k.equals("−")) expr.append(k); // رقم سالب
                return;
            }
            if (lastIsOp) expr.setCharAt(n - 1, k.charAt(0)); // استبدال المعامل
            else expr.append(k);
            return;
        }
        if (k.equals("%")) {
            if (n > 0 && (Character.isDigit(last) || last == '.')) expr.append(k);
            return;
        }
        if (k.equals(".")) {
            // منع نقطتين في الرقم نفسه
            for (int i = n - 1; i >= 0; i--) {
                char c = expr.charAt(i);
                if (c == '.') return;
                if (!Character.isDigit(c)) break;
            }
            if (n == 0 || lastIsOp) expr.append("0");
            expr.append(".");
            return;
        }
        expr.append(k);
    }

    private void refresh() {
        exprView.setText(expr.toString());
        if (expr.length() == 0) {
            resultView.setText("0");
            return;
        }
        String r = evaluate(expr.toString());
        resultView.setText(r != null ? r : resultView.getText());
    }

    // ---------- المقيِّم ----------

    private String evaluate(String s) {
        // تجاهل المعامل المعلّق في النهاية
        while (s.length() > 0 && "÷×−+".indexOf(s.charAt(s.length() - 1)) >= 0) {
            s = s.substring(0, s.length() - 1);
        }
        if (s.isEmpty()) return null;
        try {
            Parser p = new Parser(s);
            BigDecimal v = p.parseExpr();
            if (p.pos != s.length()) return "خطأ";
            v = v.round(new MathContext(12));
            String out = v.stripTrailingZeros().toPlainString();
            return out.equals("-0") ? "0" : out;
        } catch (ArithmeticException e) {
            return "خطأ";
        } catch (RuntimeException e) {
            return "خطأ";
        }
    }

    private static class Parser {
        final String s;
        int pos = 0;

        Parser(String s) {
            this.s = s;
        }

        BigDecimal parseExpr() {
            BigDecimal v = parseTerm();
            while (pos < s.length()) {
                char c = s.charAt(pos);
                if (c == '+') {
                    pos++;
                    v = v.add(parseTerm());
                } else if (c == '−') {
                    pos++;
                    v = v.subtract(parseTerm());
                } else break;
            }
            return v;
        }

        BigDecimal parseTerm() {
            BigDecimal v = parseFactor();
            while (pos < s.length()) {
                char c = s.charAt(pos);
                if (c == '×') {
                    pos++;
                    v = v.multiply(parseFactor());
                } else if (c == '÷') {
                    pos++;
                    BigDecimal d = parseFactor();
                    if (d.signum() == 0) throw new ArithmeticException("div0");
                    v = v.divide(d, new MathContext(15));
                } else break;
            }
            return v;
        }

        BigDecimal parseFactor() {
            if (pos < s.length() && s.charAt(pos) == '−') {
                pos++;
                return parseFactor().negate();
            }
            int start = pos;
            while (pos < s.length() && (Character.isDigit(s.charAt(pos)) || s.charAt(pos) == '.')) pos++;
            if (start == pos) throw new IllegalStateException("num");
            BigDecimal v = new BigDecimal(s.substring(start, pos));
            while (pos < s.length() && s.charAt(pos) == '%') {
                pos++;
                v = v.divide(BigDecimal.valueOf(100));
            }
            return v;
        }
    }
}
